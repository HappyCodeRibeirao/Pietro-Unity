# RPG Tutorial
This is the source code for the RPG Tutorial!

![alt text](http://devassets.com/img/assets/rpg-tutorial-assets/Banner.jpg "RPG Banner")

The "RPG Project" folder contains the Unity project in its current state. You can browse through previous commits to get a version of the project corresponding to a particular video.

The "Finished Project" folder contains the final example project that we made before recording the series.
