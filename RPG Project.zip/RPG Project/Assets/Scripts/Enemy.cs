using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* Handles interaction with the Enemy */

public class Enemy : Interactable {

	public override void Interact()
	{
		base.Interact();
		// Attack the enemy
	}

}
