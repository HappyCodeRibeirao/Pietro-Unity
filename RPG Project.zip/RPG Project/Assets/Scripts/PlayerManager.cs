using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* Keeps track of the player */

public class PlayerManager : MonoBehaviour {

	public GameObject player;

}
